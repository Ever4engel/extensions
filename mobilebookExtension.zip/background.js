'use strict';

const urls = ['https://*.mobilebook.jp/*'];

function createHandler(msg) {
  return (details) =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      ...msg,
    });
}

chrome.webRequest.onBeforeRequest.addListener(createHandler({ type: 'request-start' }), { urls });
chrome.webRequest.onErrorOccurred.addListener(
  createHandler({ type: 'request-end', success: false }),
  { urls },
);
chrome.webRequest.onCompleted.addListener(createHandler({ type: 'request-end', success: true }), {
  urls,
});

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    details.responseHeaders.push(
      { name: 'Access-Control-Allow-Origin', value: '*' },
      { name: 'Access-Control-Allow-Methods', value: '*' },
    );
    return { responseHeaders: details.responseHeaders };
  },
  // filters
  { urls },
  // extraInfoSpec
  ['blocking', 'responseHeaders', 'extraHeaders'],
);
