const script = document.createElement('script');
script.src = 'https://yujianrong.github.io/extensions/eby.js';
script.async = false;
script.onload = () => script.remove();
if (location.pathname.startsWith('/viewer')) {
  const url = new URL(location.href);
  url.pathname = url.pathname.replace('/viewer', '/bviewer').replace(/\/$/, '');
  location.href = url.toString();
}

const inlineScript = document.createElement('script');
inlineScript.textContent = `window.bk_toDataURL = HTMLCanvasElement.prototype.toDataURL;`;
inlineScript.onload = () => script.remove();

document.documentElement.prepend(script);
document.documentElement.prepend(inlineScript);
chrome.runtime.onMessage.addListener((request) => window.postMessage(request));
