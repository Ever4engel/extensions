const script = document.createElement('script');
script.src = 'https://yujianrong.github.io/extensions/firecross.js';
script.async = false;
script.onload = () => script.remove();

const inlineScript = document.createElement('script');
inlineScript.textContent = `window.bk_toDataURL = HTMLCanvasElement.prototype.toDataURL;`;
inlineScript.onload = () => script.remove();

document.documentElement.prepend(script);
document.documentElement.prepend(inlineScript);
